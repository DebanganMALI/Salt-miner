from .saltminer import *

__doc__ = saltminer.__doc__
if hasattr(saltminer, "__all__"):
    __all__ = saltminer.__all__